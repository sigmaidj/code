#!/usr/bin/env bash
touch public/users.json
