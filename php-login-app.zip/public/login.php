<?php
session_start();

$usersFile = "users.json";
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

$username = $_POST['username'];
$password = $_POST['password'];

if (!isset($users[$username]) || !password_verify($password, $users[$username])) {
  die("Invalid login. <a href='index.php'>Try again</a>");
}

$_SESSION['username'] = $username;
header("Location: index.php");
