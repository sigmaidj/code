<?php
session_start();
if (isset($_SESSION['username'])) {
  echo "<h1>Welcome, {$_SESSION['username']}!</h1><a href='logout.php'>Logout</a>";
} else {
?>
  <h1>Login</h1>
  <form method="POST" action="login.php">
    <input name="username" required placeholder="Username"><br>
    <input name="password" type="password" required placeholder="Password"><br>
    <button type="submit">Login</button>
  </form>

  <h1>Register</h1>
  <form method="POST" action="register.php">
    <input name="username" required placeholder="Username"><br>
    <input name="password" type="password" required placeholder="Password"><br>
    <button type="submit">Register</button>
  </form>
<?php
}
?>