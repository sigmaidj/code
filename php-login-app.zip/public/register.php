<?php
session_start();

$usersFile = "users.json";
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

$username = $_POST['username'];
$password = $_POST['password'];

if (isset($users[$username])) {
  die("User already exists. <a href='index.php'>Back</a>");
}

$users[$username] = password_hash($password, PASSWORD_DEFAULT);
file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

$_SESSION['username'] = $username;
header("Location: index.php");
